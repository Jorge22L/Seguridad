package entidades;

public class RolOpciones 
{
	private int idRolOpc;
	private int idRol;
	private int idOpcion;
	public int getIdRolOpc() {
		return idRolOpc;
	}
	public void setIdRolOpc(int idRolOpc) {
		this.idRolOpc = idRolOpc;
	}
	public int getIdRol() {
		return idRol;
	}
	public void setIdRol(int idRol) {
		this.idRol = idRol;
	}
	public int getIdOpcion() {
		return idOpcion;
	}
	public void setIdOpcion(int idOpcion) {
		this.idOpcion = idOpcion;
	}
	
	
}
