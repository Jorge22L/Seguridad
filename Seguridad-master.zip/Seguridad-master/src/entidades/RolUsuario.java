package entidades;

public class RolUsuario 
{
	private int idRolUsuario;
	private int idUsuario;
	private int idRol;
	public int getIdRolUsuario() {
		return idRolUsuario;
	}
	public void setIdRolUsuario(int idRolUsuario) {
		this.idRolUsuario = idRolUsuario;
	}
	public int getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}
	public int getIdRol() {
		return idRol;
	}
	public void setIdRol(int idRol) {
		this.idRol = idRol;
	}
	
}
