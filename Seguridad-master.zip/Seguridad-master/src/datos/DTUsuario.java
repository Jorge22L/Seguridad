package datos;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;

import entidades.Usuario;
import vistas.Usuario_vs_Rol_Opciones;

public class DTUsuario {

	PoolConexion pc = PoolConexion.getInstance();
	Connection cn = PoolConexion.getConnection();
	ResultSet rs = null;
	
	public ArrayList<Usuario> listarUsuario()
	{
		ArrayList<Usuario> roles = new ArrayList<Usuario>();
		String sql = "SELECT * from public.usuario ";
		
		try 
		{
			PreparedStatement ps = cn.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, 
					ResultSet.CONCUR_UPDATABLE,ResultSet.HOLD_CURSORS_OVER_COMMIT);
			rs = ps.executeQuery();
			
			while(rs.next())
			{
				Usuario r = new Usuario();
				r.setIdUsuario(rs.getInt("idUsuario"));
				r.setPrimerNombre(rs.getString("primerNombre"));
				r.setSegundoNombre(rs.getString("segundoNombre"));
				r.setPrimerApellido(rs.getString("primerApellido"));
				r.setSegundoApellido(rs.getString("segundoApellido"));
				r.setUsuario(rs.getString("usuario"));
				r.setPwd(rs.getString("pwd"));
				r.setFechaCreacion(rs.getDate("fechaCreacion"));
				
			
				roles.add(r);
			}
		} 
		catch (SQLException e) 
		{
			System.err.println("DATOS: ERROR AL OBTENER ROLES");
			e.printStackTrace();
		}
		return roles;
	}
	
	public String md5(String input)
	{
		try { 
			  
            // Static getInstance method is called with hashing MD5 
            MessageDigest md = MessageDigest.getInstance("MD5"); 
  
            // digest() method is called to calculate message digest 
            //  of an input digest() return array of byte 
            byte[] messageDigest = md.digest(input.getBytes()); 
  
            // Convert byte array into signum representation 
            BigInteger no = new BigInteger(1, messageDigest); 
  
            // Convert message digest into hex value 
            String hashtext = no.toString(16); 
            while (hashtext.length() < 32) { 
                hashtext = "0" + hashtext; 
            } 
            return hashtext; 
        }  
  
        // For specifying wrong message digest algorithms 
        catch (NoSuchAlgorithmException e) { 
            throw new RuntimeException(e); 
        } 
				
	}
	
	public boolean guardarUsuario(Usuario u)
	{
		boolean guardado = false;
		LocalDateTime now = LocalDateTime.now();
		Timestamp sqlnow = Timestamp.valueOf(now);
		
		try 
		{
			this.listarUsuario();
			rs.moveToInsertRow();
			rs.updateInt("idUsuario", u.getIdUsuario());
			rs.updateString("primerNombre", u.getPrimerNombre());
			rs.updateString("segundoNombre", u.getSegundoNombre());
			rs.updateString("primerApellido", u.getPrimerApellido());
			rs.updateString("segundoApellido", u.getSegundoApellido());
			rs.updateString("usuario", u.getUsuario());
			rs.updateString("pwd", md5(u.getPwd()));
			rs.updateTimestamp("fechaCreacion", sqlnow);
			rs.insertRow();
			rs.moveToCurrentRow();
			guardado = true;
		} 
		catch (Exception e) 
		{
			System.err.println("DATOS: ERROR -> Error al guardar Rol " + e.getMessage());
			e.printStackTrace();
		}
		
		return guardado;
	}
	
	public boolean LoginUsuario(Usuario_vs_Rol_Opciones u)
	{
		boolean encontrado = false;
		
		PreparedStatement ps;
		String sql = ("SELECT * from public.usuario_vs_roles_opciones where usuario = ? AND pwd = ? AND \"idRol\" = ? ");
		try 
		{
			ps = cn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ps.setString(1, u.getUsuario());
			ps.setString(2, u.getPwd());
			ps.setInt(3, u.getIdRol());
			
			rs = ps.executeQuery();
			
			if(rs.next())
			{
				encontrado = true;
			}
			else
			{
				encontrado = false;
			}
			
		} 
		catch (Exception e) 
		{
			System.out.println("DATOS: ERROR AL VERIFICAR EL LOGIN "+ e.getMessage());
			e.printStackTrace();
		}
		
		return encontrado;
	}
	
//	public boolean eliminarRol(Rol r)
//	{
//		/*
//		 * Estados
//		 * 1 - Agregado
//		 * 2 - Modificado
//		 * 3 - Eliminado
//		 *  */
//		
//		boolean eliminado = false;
//		PreparedStatement ps;
//		String sql = "Update public.rol set estado=3 where \"idRol\" = ?";
//		
//		try 
//		{
//			ps = cn.prepareStatement(sql);
//			ps.setInt(1, r.getIdRol());
//			ps.executeUpdate();
//			eliminado = true;
//		} 
//		catch (Exception e) 
//		{
//			System.err.println("DATOS: ERROR -> Error al eliminar Rol " + e.getMessage());
//			e.printStackTrace();
//		}
//		
//		return eliminado;
//	}
//	
//	public boolean modificarRol(Rol r)
//	{
//		boolean modificado = false;
//		PreparedStatement ps;
//		String sql = "Update public.rol set descripcion= ?, estado = 2 where \"idRol\" = ?";
//				
//		try 
//		{
//			ps = cn.prepareStatement(sql);
//			ps.setString(1, r.getDescripcion());
//			ps.setInt(2, r.getIdRol());
//			ps.executeUpdate();
//			modificado = true;
//		} 
//		catch (Exception e) 
//		{
//			System.err.println("DATOS: ERROR-> Error al modificar Rol " +e.getMessage());
//			e.printStackTrace();
//		}
//		return modificado;
//	}

}
